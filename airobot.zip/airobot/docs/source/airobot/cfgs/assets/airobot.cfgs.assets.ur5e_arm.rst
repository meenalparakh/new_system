airobot.cfgs.assets.ur5e\_arm
================================

.. automodule:: airobot.cfgs.assets.ur5e_arm
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../../src/airobot/cfgs/assets/ur5e_arm.py