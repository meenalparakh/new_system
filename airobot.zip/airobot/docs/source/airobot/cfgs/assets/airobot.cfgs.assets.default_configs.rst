airobot.cfgs.assets.default\_configs
====================================

.. automodule:: airobot.cfgs.assets.default_configs
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../../src/airobot/cfgs/assets/default_configs.py
