airobot.cfgs.assets.yumi\_parallel\_jaw
=======================================

.. automodule:: airobot.cfgs.assets.yumi_parallel_jaw
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../../src/airobot/cfgs/assets/yumi_parallel_jaw.py