airobot.cfgs.assets.robotiq2f140
================================

.. automodule:: airobot.cfgs.assets.robotiq2f140
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../../src/airobot/cfgs/assets/robotiq2f140.py