airobot.cfgs.assets
====================

.. toctree::

   airobot.cfgs.assets.default_configs
   airobot.cfgs.assets.pybullet_camera
   airobot.cfgs.assets.realsense_camera
   airobot.cfgs.assets.robotiq2f140
   airobot.cfgs.assets.yumi_parallel_jaw
   airobot.cfgs.assets.ur5e_arm
   airobot.cfgs.assets.yumi_arm
   airobot.cfgs.assets.yumi_dual_arm