airobot.cfgs.assets.pybullet\_camera
====================================

.. automodule:: airobot.cfgs.assets.pybullet_camera
    :members:
    :undoc-members:
    :show-inheritance:
    
.. literalinclude:: ../../../../../src/airobot/cfgs/assets/pybullet_camera.py
