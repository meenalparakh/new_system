airobot.cfgs.assets.realsense\_camera
=====================================

.. automodule:: airobot.cfgs.assets.realsense_camera
    :members:
    :undoc-members:
    :show-inheritance:
    
.. literalinclude:: ../../../../../src/airobot/cfgs/assets/realsense_camera.py
