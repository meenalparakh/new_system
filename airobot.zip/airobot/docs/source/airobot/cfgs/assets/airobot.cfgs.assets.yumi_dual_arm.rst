airobot.cfgs.assets.yumi\_dual\_arm
===================================

.. automodule:: airobot.cfgs.assets.yumi_dual_arm
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../../src/airobot/cfgs/assets/yumi_dual_arm.py