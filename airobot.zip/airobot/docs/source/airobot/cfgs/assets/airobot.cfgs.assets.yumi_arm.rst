airobot.cfgs.assets.yumi\_arm
=============================

.. automodule:: airobot.cfgs.assets.yumi_arm
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../../src/airobot/cfgs/assets/yumi_arm.py