airobot.cfgs.yumi\_grippers\_cfg
================================

.. automodule:: airobot.cfgs.yumi_grippers_cfg
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../src/airobot/cfgs/yumi_grippers_cfg.py