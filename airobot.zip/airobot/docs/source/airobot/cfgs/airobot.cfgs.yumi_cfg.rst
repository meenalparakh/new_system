airobot.cfgs.yumi\_cfg
=============================

.. automodule:: airobot.cfgs.yumi_cfg
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../src/airobot/cfgs/yumi_cfg.py