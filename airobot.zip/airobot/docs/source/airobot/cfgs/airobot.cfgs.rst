airobot.cfgs
====================

.. toctree::

   airobot.cfgs.ur5e_cfg
   airobot.cfgs.ur5e_2f140_cfg
   airobot.cfgs.ur5e_stick_cfg
   airobot.cfgs.yumi_cfg
   airobot.cfgs.yumi_grippers_cfg
   airobot.cfgs.yumi_palms_cfg
   assets/airobot.cfgs.assets
