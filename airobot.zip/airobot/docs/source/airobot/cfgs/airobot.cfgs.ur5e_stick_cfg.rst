airobot.cfgs.ur5e\_stick\_cfg
=============================

.. automodule:: airobot.cfgs.ur5e_stick_cfg
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../src/airobot/cfgs/ur5e_stick_cfg.py