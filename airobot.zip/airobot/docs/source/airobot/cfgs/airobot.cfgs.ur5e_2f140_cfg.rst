airobot.cfgs.ur5e\_2f140\_cfg
=============================

.. automodule:: airobot.cfgs.ur5e_2f140_cfg
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../src/airobot/cfgs/ur5e_2f140_cfg.py