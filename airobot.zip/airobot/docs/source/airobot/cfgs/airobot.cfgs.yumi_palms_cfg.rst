airobot.cfgs.yumi\_palms\_cfg
=============================

.. automodule:: airobot.cfgs.yumi_palms_cfg
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../src/airobot/cfgs/yumi_palms_cfg.py