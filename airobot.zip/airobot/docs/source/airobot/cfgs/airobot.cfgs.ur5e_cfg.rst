airobot.cfgs.ur5e\_cfg
=============================

.. automodule:: airobot.cfgs.ur5e_cfg
    :members:
    :undoc-members:
    :show-inheritance:

.. literalinclude:: ../../../../src/airobot/cfgs/ur5e_cfg.py