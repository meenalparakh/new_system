airobot.arm.ur5e\_real
=============================

.. automodule:: airobot.arm.ur5e_real
    :members:
    :undoc-members:
    :show-inheritance:
