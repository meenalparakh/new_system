airobot.sensor.camera.rgbdcam\_real
==========================================

.. automodule:: airobot.sensor.camera.rgbdcam_real
    :members:
    :undoc-members:
    :show-inheritance:
