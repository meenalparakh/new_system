Welcome to AIRobot's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Introduction:

   airobot/README

.. toctree::
   :maxdepth: 4
   :caption: Python API:

   airobot/airobot





Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
